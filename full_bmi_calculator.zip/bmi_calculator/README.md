# BMI Calculator App
A basic Flutter app to calculate Body Mass Index (BMI).